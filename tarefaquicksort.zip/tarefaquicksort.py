import modquicksort as mod
import json
def carregabd(nomearq):
    lista = []
    with open(nomearq, 'r') as arq:
        
        
        keylist = ['Placa','Modelo','Marca', 'Kilometragem', 'Cor', 'Combustivel' ]
        lstdic = []
        jsonlst = []
        lst = []
        for linha in arq:
            linhalst = linha.strip().split(',')
          
            dict = {}
            for i in keylist:
                dict[i] = linhalst[keylist.index(i)]
            lstdic.append(dict)
        for element in lstdic:

            jsonlst.append(json.dumps(element))
            
    return lstdic
       
        
            
            
    
    
def main():
    lista = carregabd('bdveiculos2.txt')
    lista_quickr = mod.quickr(lista)


    with open('quickr-out.txt', 'w') as arquivo_quickr:
        for veiculo in lista_quickr:
            linha = json.dumps(veiculo)
            arquivo_quickr.write(linha + '\n')
    
    lista_quicknr = mod.quicknr(lista)


    with open('quicknr-out.txt', 'w') as arquivo_quicknr:
        for veiculo in lista_quicknr:
            linha = json.dumps(veiculo)
            arquivo_quicknr.write(linha + '\n')
main()
