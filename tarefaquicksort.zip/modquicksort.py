def quickr(lista):
    criterios = ['Combustivel', 'Cor', 'Marca', 'Modelo', 'Kilometragem']
    
    if len(lista) <= 1:
        return lista

    pivo = lista[len(lista) // 2]
    menores, iguais, maiores = [], [], []

    for item in lista:
        comparacoes_menores = []
        comparacoes_maiores = []

        for chave in criterios:
            comparacao_menor = item[chave] < pivo[chave]
            comparacao_maior = item[chave] > pivo[chave]

            comparacoes_menores.append(comparacao_menor)
            comparacoes_maiores.append(comparacao_maior)

        if all(comparacoes_menores):
            menores.append(item)
        elif all(comparacoes_maiores):
            maiores.append(item)
        else:
            iguais.append(item)

    return quickr(menores) + iguais + quickr(maiores)

def quicknr(lista):
    criterios = [ 'Combustivel', 'Cor', 'Marca', 'Modelo', 'Kilometragem']
    tamanho = len(lista)
    stack = [(0, tamanho - 1)]
    
    while stack:
        inicio, fim = stack.pop()
        
        while inicio < fim:
            pivo = lista[fim]
            i = inicio
            
            for j in range(inicio, fim):
                comparacoes = []
                
                for chave in criterios:
                    comparacao = lista[j][chave] <= pivo[chave]
                    comparacoes.append(comparacao)
                
                if all(comparacoes):
                    lista[i], lista[j] = lista[j], lista[i]
                    i += 1
            
            lista[i], lista[fim] = lista[fim], lista[i]
            
            if i - inicio < fim - i:
                stack.append((i + 1, fim))
                fim = i - 1
            else:
                stack.append((inicio, i - 1))
                inicio = i + 1
    
    return lista




